using System.Collections.Generic;
using UnityEngine;

public class TracingPart : MonoBehaviour {
    public List<int> orders;
    public bool isSuccess;
    public int priority;
}
